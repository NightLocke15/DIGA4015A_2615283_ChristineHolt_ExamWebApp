import React from "react";
import ChangePassword from "../Components/Settings/ChangePassword";

function ForgotPassword() {


    return (
        <section>
            <h1>Change Password:</h1>
            <ChangePassword />
        </section>
    )
}

export default ForgotPassword;